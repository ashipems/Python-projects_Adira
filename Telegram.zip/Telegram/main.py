from telegram.ext import *
import Responses as R

def handle_messages(update,context):
    text = str(update.message.text)  
    c, response = R.sample_responses(text)  
    if c==1:
        update.message.reply_text(response) 
    else:
        context.bot.send_photo(chat_id=update.effective_chat.id, photo=response)

updater = Updater('1798618640:AAEhpRkF9subG0pbMKoNu1ijT-Xj_eh10AM')  
d = updater.dispatcher 

d.add_handler(MessageHandler(Filters.text, handle_messages))

updater.start_polling()  
updater.idle()
