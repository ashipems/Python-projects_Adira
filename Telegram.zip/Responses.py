from datetime import datetime
import pytz


def sample_responses(user_input):
    input_text = str(user_input).lower()

    if input_text in ["/start", "hi", "hi!", "hello", "hey"]:
        return (1,"Hey! I'm Alpha. Do you want to know the time or today's date?")

    if input_text in ["time", "time?"]:
        return (1, "Do you want to know the time in India, England or United States?")

    if input_text == "india":
        time_zone = pytz.timezone('Asia/Kolkata')
        now = datetime.now(time_zone)
        return (1,"Time -  " + now.strftime('%H : %M : %S'))
    if input_text == "england":
        time_zone = pytz.timezone('Europe/London')
        now = datetime.now(time_zone)
        return (1,"Time -  " + now.strftime('%H : %M : %S'))
    if input_text in ["united states", "us"]:
        time_zone = pytz.timezone('America/New_York')
        now = datetime.now(time_zone)
        return (1,"Time -  " + now.strftime('%H : %M : %S'))

    if input_text in ["date", "date?"]:
        date = datetime.now()
        return (1,date.strftime('%d - %B - %Y'))

    if input_text in ["bye", "ttyl", "good bye"]:
        return (1,"It was nice chatting with you. Bye!")

    if input_text in ["pic", "photo", "image?"]:
        return (2,"https://www.google.com/imgres?imgurl=https%3A%2F%2Fi.pinimg.com%2F736x%2Fc6%2Fde%2F4f%2Fc6de4fbc92c32c25dd90c41884968d63--die-minions-minion-s.jpg&imgrefurl=https%3A%2F%2Fwww.pinterest.com%2Fpin%2F526850856399393674%2F&tbnid=17EF0BFtexW5GM&vet=12ahUKEwiqjsPZudPyAhVHXCsKHTniCDIQMygAegUIARDKAQ..i&docid=Jg5RAiM1Uu4H1M&w=736&h=1309&q=minion%20cute&ved=2ahUKEwiqjsPZudPyAhVHXCsKHTniCDIQMygAegUIARDKAQ")

    return (1,"Sorry,I didn't understand you")